-- Window Function:

-- Row number:

-- Q1)
select * 
from (

	select *
	from
		(select city, sum(sales) as city_sales
		from global_superstore
		group by City
		order by city_sales desc
		limit 20) as t   
	order by city_sales asc
	limit 10) as t2
order by city_sales desc
;

-- or
select city, sum(sales) as city_sales
from global_superstore
group by City
order by city_sales desc
-- offset next 10 rows
-- fetch next 10 rows only
LIMIT 10 
OFFSET 10
 ;

-- or
select *
from

		(select city, 
				sum(sales) as city_sales, 
				row_number() over(order by sum(sales) desc) as Rn
		from global_superstore
		group by City) as t
-- where  Rn >= 11 and Rn <= 20 
where Rn between 11 and 20
;

-- Q2) find top 3 selling cities of each country
select *
from
		(select 
			Country, City, sum(Sales) as city_sales,
			row_number() over(partition by country order by sum(Sales) desc) as Rn   
		from global_superstore
		group by Country, City) as t
where Rn <= 3
;

-- Rank
-- Q3) Find the top 30 products based on quantity sold.
select *
from
		(select Product_ID, Product_Name, sum(Quantity) as total_quantity,
				rank() over(order by sum(quantity) desc) as Rn
		from global_superstore
		group by Product_ID, Product_Name) as t
where Rn <= 30 
;

-- window function with Aggregation

-- Q4) show quater over quarter sales as well as cumulative sales.
select *, sum(quarter_sales) over(order by 'year' ) as cumulative_sales
from
		(select year(order_date) as 'year',  sum(sales) as quarter_sales
		from global_superstore
		group by year(order_date)) as t
;

-- Q5)show quarter over quarter percent sales as well  moving average sales.

-- LAG :

-- Q) show quarter over quarter percent growth in sales

-- LEAD:

-- Q) show quarter over quarter percent growth in sales.






















