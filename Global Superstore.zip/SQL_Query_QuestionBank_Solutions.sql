-- SQL Query Question bank solution --
-- SQL Query 10 Mark each:
use new_schema;

-- Q. 1) Find the list of all the cities from India, China, and Japan.				(10) Marks
SELECT 
    country, city
FROM
    orders
WHERE
    Country IN ('india' , 'china', 'japan')
GROUP BY country , city;

-- Q. 2)	Find the total sales and profit for the third quarter of 2022.			(10) Marks
SELECT 
    YEAR(order_date) AS 'year',
    QUARTER(order_date) AS 'Quarter_3',
    round(SUM(sales),2) AS 'total_sales',
    round(sum(profit),2) as "total_profit"
FROM
    orders
WHERE
    YEAR(order_date) = 2022
        AND QUARTER(order_date) = 3
GROUP BY YEAR(order_date) , QUARTER(order_date) 
ORDER BY QUARTER(order_date) DESC;

-- or
SELECT 
    SUM(sales) 'total salesfor 3rd q',
    SUM(profit) 'total profit for 3rd q'
FROM
    Orders
WHERE
    Order_Date BETWEEN '2022-07-01' AND '2022-09-30';

-- Q. 3) 	Find the list of the top 15 customers by quantity of products purchased.		(10) Marks
SELECT 
    Customer_Name, SUM(Quantity) AS total_quantity
FROM
    orders
GROUP BY Customer_Name 
ORDER BY total_quantity DESC
LIMIT 15;

-- Q. 4)	Find the customers who have placed more than one order.			(10) Marks
SELECT 
    COUNT(Order_ID) AS total_order_count,
    Customer_Name,
    Customer_ID
FROM
    orders
GROUP BY Customer_Name , Customer_ID
HAVING COUNT(Order_ID) >= 2
ORDER BY COUNT(Order_ID)
;

-- Q. 5)	Find the total sales of ‘Chairs’ sub-category in India.				(10) Marks
select Sub_Category, sum(sales) as total_sales, country
from orders
where Sub_Category = "chairs" and country = "india"
;

-- Q. 6)	Find the total sales and profit for the last February month. 			(10) Marks
select year(order_date) as "year",
		month(order_date) as "Feb_month" , 
        sum(sales) as total_sales, 
        sum(Profit) as total_profit
from orders
where monthname(order_date) = "february" 
and year(current_date()) - year(order_date) < 1
group by month(order_date), year(order_date)
order by "year" ;

-- Q. 7) 	Find the list of the 20 lowest-selling cities.					(10) Marks
select City, round(sum(sales),1) as total_sales
from orders
group by city
order by total_sales asc 
limit 20;

-- Q. 8) 	Find the row with the fifth highest profit value.					(10) Marks
select *
from (select profit, 
			 rank() over(order by profit desc) as Rn
		from orders) as T
where Rn = 5 ;

-- Q. 9)	Find the list of all the Indian cities whose name contains the letter ‘K’.(10) Marks
select city
from orders
where city like "%k%";

-- Q. 10)	Find the total sales generated in 2023 and 2024 together. 			(10) Marks
SELECT 
    YEAR(order_date) AS 'year',
    ROUND(SUM(sales), 2) AS total_sales,
    ROUND(SUM(profit), 2) AS total_profit
FROM
    orders
WHERE
    YEAR(order_date) IN ('2023' , '2024')
GROUP BY YEAR(order_date)
;

-- Q. 11)	Find the number of orders placed by each customer. 				(10) Marks
SELECT DISTINCT
    Customer_ID,
    Customer_Name,
    COUNT(Order_ID) AS total_order_placed
FROM
    orders
GROUP BY Customer_ID , Customer_Name
ORDER BY total_order_placed DESC;

-- Q. 12) 	Find the percent contribution from each country in total sales. 			(10) Marks
SELECT 
    country,
    CONCAT(SUM(sales) / (SELECT 
                    SUM(sales)
                FROM
                    orders) * 100) AS percentage_contribution
FROM
    orders
GROUP BY country
;

-- Q. 13) 	Show each country’s sales is what percent of the sales of India. 			(10) Marks
select country, concat(sum(sales)/ 
									(select sum(sales)
                                     from orders
                                     where country = "india") * 100) as percentage_contribution
from orders
group by country
order by country;

-- Q. 14)	Find the customers who have placed at least 1 order in the last 100 days.	(10) Marks
select Customer_Name, count(order_id) as total_orders
from orders
where Order_Date >= CURDATE() - INTERVAL 100 DAY
group by Customer_Name
having count(Order_ID) >= 1
order by total_orders asc
;
-- or
select Customer_Name, count(order_id) as total_orders
from orders
where Order_Date >= CURDATE() - 100
group by Customer_Name
having count(Order_ID) >= 1
order by total_orders asc;



-- SQL query: 20 Marks each 
-- Q. 1)	Find the country-wise customer count.
use	new_schema_2;
select location.country, count(fact.customer_id) as customer_count
from location
inner join fact 
on fact.location_id = location.location_id
group by location.country
order by customer_count desc;

-- Q. 2) 	In 2023, which cities had sales less than 2000?					(20) Marks
select year(fact.order_date) as "year" , location.city, round(sum(fact.sales),2) as Total_sales
from location
join fact on 
location.location_id = fact.location_id
where year(fact.order_date) = 2023
group by location.city, year(fact.order_date)
having Total_sales < 2000  
order by total_sales desc
;

-- Q. 3) Find segment and subcategory-wise sales and profit.				(20) Marks
select c.segment, 
		p.sub_category, 
        sum(f.sales) as total_sales, 
        sum(f.profit) as total_profit,
        row_number() over (order by sum(f.sales)) as "r_number"
from customer as c
inner join fact as f
on c.customer_id = f.customer_id
inner join product as p
on p.product_id = f.product_id
group by c.segment, p.sub_category
;

-- Q. 4)  	Find the total number of cities with sales of more than 50000.	
SELECT 
    COUNT(*) AS total_cities
FROM
    (SELECT 
        location.city, SUM(fact.sales) AS 'Total_sales'
    FROM
        location
    INNER JOIN fact ON location.location_id = fact.location_id
    GROUP BY location.city
    HAVING Total_sales > 50000) AS tnc
; 

-- Q. 5)	Find year-wise total sales and total profit for different countries. 
select 
		year(fact.order_date) as year,
        location.country,
		sum(fact.sales) as total_sales,
        sum(fact.profit) as total_profit
from fact
inner join location
on fact.location_id = location.location_id
group by year(fact.order_date), location.country
order by "year" desc
;

-- Q. 6) Find the list of cities that faced overall loss in Texas state of United States.	(20) Marks
select count(*)	 as total_list
from	
        (select 
				location.city, 
				location.state,
				round(sum(fact.profit),2) as "total_loss"
		from location
		inner join fact
		on location.location_id = fact.location_id
		where state = "texas"
		group by location.city, location.state
		having total_loss < 0
		order by total_loss) as T ;
        















