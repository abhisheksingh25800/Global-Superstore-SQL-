20 MARKS SQL QUERRIES SOLUTION

--1-FIND THE COUNTRYWISE CUSTOMER COUNT

USE ankita 
SELECT COUNTRY,COUNT([Customer ID])'CUSTOMER COUNT'
FROM Fact$ INNER JOIN Location$ ON FACT$.[Location ID] = LOCATION$.[Location ID]
GROUP BY Country





-- 2 --IN 2023, WHICH CITIES HAD SALES LESS THAN 2000?

USE ankita
SELECT YEAR(Fact$.[Order Date])'YEAR',City,SUM(SALES)'TOTAL SALES'
FROM Fact$ INNER JOIN Location$ ON Fact$.[Location ID]=Location$.[Location ID]
WHERE YEAR(Fact$.[Order Date])='2023'
GROUP BY YEAR(Fact$.[Order Date]),City
HAVING SUM(Sales)<=2000





--- 3 --FIND SEGMENT AND SUB- CATEGORY WISE SALES AND PROFIT

USE ankita
SELECT [Sub-Category], Segment,SUM(SALES)'TOTAL SALES',SUM(PROFIT)'TOTAL PROFIT'
FROM Fact$ INNER JOIN Product$ ON Fact$.[Product ID]=Product$.[Product ID]
           INNER JOIN Customer$ ON Fact$.[Customer ID]=Customer$.[Customer ID]
GROUP BY [Sub-Category], Segment





---4 --FIND TOTAL NO. OF CITIES WITH SALES MORE THAN 50000
NOTE:
( THIS SOLUTION IS STILL INCOMPLETE SO DON�T COPY OR LEARN IT)

USE ankita 
 SELECT COUNT(*)
 FROM(SELECT COUNT(*)'CITY COUNT',SUM(SALES)
FROM Fact$ INNER JOIN Location$ ON
     Location$.[Location ID]=Fact$.[Location ID]
GROUP BY City
HAVING  SUM(Sales)>=50000)


--5 -find year wise total sales and total profit for different countries

USE ankita
SELECT  YEAR([Order Date]), Country,SUM(SALES)'TOTAL SALES',SUM(PROFIT)'TOTAL PROFIT'
FROM Fact$ INNER JOIN Location$ ON Location$.[Location ID]=Fact$.[Location ID]
GROUP BY YEAR([Order Date]), Country
ORDER BY YEAR([ORDER DATE])





---6 FIND THE LIST OF CITIES THAT FACED OVERALL LOSS IN TEXAS STATE OF UNITED STATES

USE ankita
SELECT City'texas states cities in USA',SUM(PROFIT)
FROM Fact$ INNER JOIN Location$ ON 
      Location$.[Location ID]=Fact$.[Location ID]
	  WHERE Country= 'UNITED STATES' AND State='Texas'
	  GROUP BY City
	  HAVING SUM(profit)<0



	 
