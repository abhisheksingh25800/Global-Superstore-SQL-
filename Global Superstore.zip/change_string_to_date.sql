UPDATE `new_schema`.`global_superstore`
SET `Order_Date` = STR_TO_DATE(`Order_Date`, '%d-%b-%y')
WHERE `Order_Date` IS NOT NULL;

UPDATE `new_schema`.`global_superstore`
SET `Order_Date` = STR_TO_DATE(`Order_Date`, '%d-%b-%y')
WHERE `Order_Date` IS NOT NULL;

SET SQL_SAFE_UPDATES = 0;

UPDATE `new_schema`.`global_superstore`
SET `ship_Date` = STR_TO_DATE(`ship_Date`, '%d-%b-%y')
WHERE `ship_Date` IS NOT NULL AND `ship_Date` != '';

SET SQL_SAFE_UPDATES = 1;


